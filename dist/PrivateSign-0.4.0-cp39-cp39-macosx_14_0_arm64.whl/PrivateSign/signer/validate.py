def validate():
    print("Test Validate")