# interface.py
from .signer import cms

def sign():
    return cms.sign()